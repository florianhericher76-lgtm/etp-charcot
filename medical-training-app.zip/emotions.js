// Card Game - Emotions and Difficulties Selection

// All available cards separated by type
const emotionCards = [
    { id: 2, name: 'AMOUR', color: '#E8D5F2' },
    { id: 3, name: 'PEUR', color: '#E8D5F2' },
    { id: 4, name: 'ANXIÉTÉ', color: '#E8D5F2' },
    { id: 5, name: 'COLÈRE', color: '#E8D5F2' },
    { id: 6, name: 'DÉGOÛT', color: '#E8D5F2' },
    { id: 7, name: 'JOIE', color: '#E8D5F2' },
    { id: 8, name: 'TRISTESSE', color: '#E8D5F2' },
    { id: 9, name: 'SOULAGEMENT', color: '#E8D5F2' },
    { id: 10, name: 'SURPRISE', color: '#E8D5F2' },
    { id: 11, name: 'EMBARRAS', color: '#E8D5F2' },
    { id: 12, name: 'AGACEMENT', color: '#E8D5F2' },
    { id: 13, name: 'ENNUI', color: '#E8D5F2' },
    { id: 14, name: 'AMUSEMENT', color: '#E8D5F2' },
    { id: 15, name: 'CONFUSION', color: '#E8D5F2' }
];

const difficultyCards = [
    { id: 21, name: "PERTE D'APPÉTIT", color: '#FFD4B8' },
    { id: 22, name: 'PERTE MÉMOIRE', color: '#FFD4B8' },
    { id: 23, name: 'PROBLÈME DE COMMUNICATION', color: '#FFD4B8' },
    { id: 24, name: 'HYPERACTIVITÉ', color: '#FFD4B8' },
    { id: 25, name: 'INATTENTION', color: '#FFD4B8' },
    { id: 26, name: 'IMPULSIVITÉ', color: '#FFD4B8' },
    { id: 27, name: "PERTE D'INTÉRÊT", color: '#FFD4B8' },
    { id: 28, name: "BAISSE D'ÉNERGIE", color: '#FFD4B8' }
];

// State management
const cardState = {
    selectedEmotions: [],
    selectedDifficulties: []
};

// DOM Elements
const emotionsGrid = document.getElementById('emotionsGrid');
const difficultiesGrid = document.getElementById('difficultiesGrid');
const emotionsCount = document.getElementById('emotionsCount');
const difficultiesCount = document.getElementById('difficultiesCount');
const resetBtn = document.getElementById('reset-btn');
const validateBtn = document.getElementById('validate-btn');
const summaryModal = document.getElementById('summaryModal');
const selectedEmotionsDiv = document.getElementById('selectedEmotions');
const selectedDifficultiesDiv = document.getElementById('selectedDifficulties');
const closeModalBtn = document.getElementById('closeModal');
const saveAndReturnBtn = document.getElementById('saveAndReturn');

// Initialize
function initCardGame() {
    loadSelectedCards();
    renderEmotionCards();
    renderDifficultyCards();
    updateUI();

    // Event listeners
    resetBtn.addEventListener('click', resetSelection);
    validateBtn.addEventListener('click', showSummary);
    closeModalBtn.addEventListener('click', closeSummary);
    saveAndReturnBtn.addEventListener('click', saveAndReturn);
}

// Render emotion cards
function renderEmotionCards() {
    emotionsGrid.innerHTML = '';

    emotionCards.forEach(card => {
        const cardEl = createCard(card, 'emotion');
        emotionsGrid.appendChild(cardEl);
    });
}

// Render difficulty cards
function renderDifficultyCards() {
    difficultiesGrid.innerHTML = '';

    difficultyCards.forEach(card => {
        const cardEl = createCard(card, 'difficulty');
        difficultiesGrid.appendChild(cardEl);
    });
}

// Create card element
function createCard(card, type) {
    const cardEl = document.createElement('div');
    cardEl.className = 'emotion-card';
    cardEl.dataset.id = card.id;
    cardEl.dataset.type = type;

    const selectedArray = type === 'emotion' ? cardState.selectedEmotions : cardState.selectedDifficulties;
    const isSelected = selectedArray.includes(card.id);

    if (isSelected) {
        cardEl.classList.add('selected');
    }

    cardEl.style.backgroundColor = card.color;

    cardEl.innerHTML = `
        <div class="emotion-name">${card.name}</div>
        <div class="selection-indicator">✓</div>
    `;

    cardEl.addEventListener('click', () => toggleCard(card.id, type));

    return cardEl;
}

// Toggle card selection
function toggleCard(cardId, type) {
    const selectedArray = type === 'emotion' ? cardState.selectedEmotions : cardState.selectedDifficulties;
    const index = selectedArray.indexOf(cardId);

    if (index > -1) {
        // Deselect
        selectedArray.splice(index, 1);
    } else {
        // Select only if less than 3
        if (selectedArray.length < 3) {
            selectedArray.push(cardId);
        } else {
            const typeName = type === 'emotion' ? 'émotions' : 'difficultés';
            alert(`Vous ne pouvez sélectionner que 3 ${typeName} maximum.`);
            return;
        }
    }

    saveSelectedCards();

    // Re-render specific grid
    if (type === 'emotion') {
        renderEmotionCards();
    } else {
        renderDifficultyCards();
    }

    updateUI();
}

// Update UI (counters and validate button)
function updateUI() {
    emotionsCount.textContent = cardState.selectedEmotions.length;
    difficultiesCount.textContent = cardState.selectedDifficulties.length;

    // Enable validate button only if 3 emotions AND 3 difficulties are selected
    validateBtn.disabled = !(cardState.selectedEmotions.length === 3 && cardState.selectedDifficulties.length === 3);
}

// Reset selection
function resetSelection() {
    if (!confirm('Voulez-vous vraiment recommencer votre sélection ?')) {
        return;
    }

    cardState.selectedEmotions = [];
    cardState.selectedDifficulties = [];
    saveSelectedCards();
    renderEmotionCards();
    renderDifficultyCards();
    updateUI();
}

// Show summary modal
function showSummary() {
    if (cardState.selectedEmotions.length !== 3 || cardState.selectedDifficulties.length !== 3) {
        alert('Veuillez sélectionner exactement 3 émotions ET 3 difficultés.');
        return;
    }

    // Render selected emotions
    selectedEmotionsDiv.innerHTML = '';
    cardState.selectedEmotions.forEach(cardId => {
        const card = emotionCards.find(e => e.id === cardId);
        if (card) {
            const cardEl = document.createElement('div');
            cardEl.className = 'summary-emotion-card';
            cardEl.style.backgroundColor = card.color;
            cardEl.innerHTML = `<div class="emotion-name-large">${card.name}</div>`;
            selectedEmotionsDiv.appendChild(cardEl);
        }
    });

    // Render selected difficulties
    selectedDifficultiesDiv.innerHTML = '';
    cardState.selectedDifficulties.forEach(cardId => {
        const card = difficultyCards.find(d => d.id === cardId);
        if (card) {
            const cardEl = document.createElement('div');
            cardEl.className = 'summary-emotion-card';
            cardEl.style.backgroundColor = card.color;
            cardEl.innerHTML = `<div class="emotion-name-large">${card.name}</div>`;
            selectedDifficultiesDiv.appendChild(cardEl);
        }
    });

    summaryModal.classList.remove('hidden');
}

// Close summary
function closeSummary() {
    summaryModal.classList.add('hidden');
}

// Save and return to modules
function saveAndReturn() {
    saveSelectedCards();
    alert('Vos cartes ont été enregistrées !');
    window.location.href = 'index.html';
}

// Save to localStorage
function saveSelectedCards() {
    localStorage.setItem('etpSelectedEmotions', JSON.stringify(cardState.selectedEmotions));
    localStorage.setItem('etpSelectedDifficulties', JSON.stringify(cardState.selectedDifficulties));
}

// Load from localStorage
function loadSelectedCards() {
    const savedEmotions = localStorage.getItem('etpSelectedEmotions');
    const savedDifficulties = localStorage.getItem('etpSelectedDifficulties');

    if (savedEmotions) {
        try {
            cardState.selectedEmotions = JSON.parse(savedEmotions);
        } catch (e) {
            console.error('Error loading emotions:', e);
        }
    }

    if (savedDifficulties) {
        try {
            cardState.selectedDifficulties = JSON.parse(savedDifficulties);
        } catch (e) {
            console.error('Error loading difficulties:', e);
        }
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCardGame);
} else {
    initCardGame();
}
