// Application State
const AppState = {
    currentRole: null,
    currentModule: null,
    completedModules: new Set(),
    viewedContent: new Set()
};

// DOM Elements
const elements = {
    heroSection: document.getElementById('hero-section'),
    mainContent: document.getElementById('main-content'),
    moduleDetail: document.getElementById('module-detail'),
    roleCards: document.querySelectorAll('.role-card'),
    backToHome: document.getElementById('back-to-home'),
    backToModules: document.getElementById('back-to-modules'),
    modulesGrid: document.getElementById('modules-grid'),
    roleTitle: document.getElementById('role-title'),
    roleSubtitle: document.getElementById('role-subtitle'),
    progressFill: document.getElementById('progress-fill'),
    progressText: document.getElementById('progress-text'),
    detailNumber: document.getElementById('detail-number'),
    detailTitle: document.getElementById('detail-title'),
    detailObjective: document.getElementById('detail-objective'),
    detailSkills: document.getElementById('detail-skills'),
    detailIcon: document.getElementById('detail-icon'),
    videosSection: document.getElementById('videos-section'),
    videosGrid: document.getElementById('videos-grid'),
    workshopsSection: document.getElementById('workshops-section'),
    workshopsList: document.getElementById('workshops-list')
};

// Initialize Application
function init() {
    // Initialize role icons
    initRoleIcons();

    // Add event listeners to role cards
    elements.roleCards.forEach(card => {
        card.addEventListener('click', () => {
            const role = card.getAttribute('data-role');
            selectRole(role);
        });
    });

    // Back to home
    elements.backToHome.addEventListener('click', () => {
        showView('hero');
        AppState.currentRole = null;
        updateProgress();
    });

    // Back to modules
    elements.backToModules.addEventListener('click', () => {
        showView('modules');
        AppState.currentModule = null;
    });

    // Smooth scroll for navigation links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            if (link.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });

    // Load saved state from localStorage
    loadState();
}

// Initialize Role Icons
function initRoleIcons() {
    const patientIcon = document.getElementById('patient-icon');
    const caregiverIcon = document.getElementById('caregiver-icon');

    if (patientIcon) {
        patientIcon.innerHTML = getIcon('patient', '120px');
    }
    if (caregiverIcon) {
        caregiverIcon.innerHTML = getIcon('caregiver', '120px');
    }
}

// Select Role (Patient or Caregiver)
function selectRole(role) {
    AppState.currentRole = role;
    saveState();

    const modules = role === 'patient' ? patientModules : caregiverModules;
    const roleInfo = {
        patient: {
            title: 'Parcours Patient',
            subtitle: 'Votre accompagnement personnalisé tout au long de votre parcours de soins'
        },
        caregiver: {
            title: 'Parcours Aidant',
            subtitle: 'Les ressources et formations pour accompagner votre proche au quotidien'
        }
    };

    elements.roleTitle.textContent = roleInfo[role].title;
    elements.roleSubtitle.textContent = roleInfo[role].subtitle;

    renderModules(modules);
    updateProgress();
    showView('modules');
}

// Render Modules Grid
function renderModules(modules) {
    elements.modulesGrid.innerHTML = '';

    modules.forEach(module => {
        const moduleCard = createModuleCard(module);
        elements.modulesGrid.appendChild(moduleCard);
    });
}

// Create Module Card
function createModuleCard(module) {
    const card = document.createElement('div');
    card.className = 'module-card';
    card.style.setProperty('--module-color', module.color);

    const isCompleted = AppState.completedModules.has(module.id);
    const iconHtml = getModuleIcon(AppState.currentRole, module.id, '80px');
    const checkmarkHtml = isCompleted ? getIcon('checkmark', '32px') : '';

    card.innerHTML = `
        <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
            <div style="width: 80px; height: 80px; flex-shrink: 0;">
                ${iconHtml}
            </div>
            <div style="flex: 1;">
                <div style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 0.25rem;">${module.number}</div>
                <h3 class="module-title" style="margin: 0;">${module.title}</h3>
            </div>
            ${isCompleted ? `<div style="width: 32px; height: 32px; flex-shrink: 0;">${checkmarkHtml}</div>` : ''}
        </div>
        <p class="module-objective">${module.objective}</p>
        <ul class="module-skills">
            ${module.skills.map(skill => `<li>${skill}</li>`).join('')}
        </ul>
    `;

    card.addEventListener('click', () => {
        showModuleDetail(module);
    });

    return card;
}

// Show Module Detail
function showModuleDetail(module) {
    AppState.currentModule = module;

    // Check if this is the Bilan module
    const isBilan = module.id === 0;

    // Hide or show the module header section
    const moduleHeader = document.querySelector('.module-header');
    if (moduleHeader) {
        moduleHeader.style.display = isBilan ? 'none' : 'block';
    }

    elements.detailNumber.textContent = module.number;
    elements.detailTitle.textContent = module.title;
    elements.detailObjective.textContent = module.objective;
    elements.detailIcon.innerHTML = getModuleIcon(AppState.currentRole, module.id, '80px');

    // Render skills
    elements.detailSkills.innerHTML = module.skills
        .map(skill => `<li>${skill}</li>`)
        .join('');

    // Render content sections
    renderVideos(module.content.videos);
    renderWorkshops(module.content.workshops);

    showView('detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Render Videos Section
function renderVideos(videos) {
    if (!videos || videos.length === 0) {
        elements.videosSection.classList.add('hidden');
        return;
    }

    elements.videosSection.classList.remove('hidden');
    elements.videosGrid.innerHTML = '';

    videos.forEach(video => {
        const videoItem = document.createElement('div');
        videoItem.className = 'video-item';
        const playIcon = getIcon('video', '48px');
        videoItem.innerHTML = `
            <div class="video-thumbnail">
                ${playIcon}
                <div class="play-button">${getIcon('play', '48px')}</div>
            </div>
            <div class="video-info">
                <div class="video-title">${video.title}</div>
                <div class="video-duration">
                    <svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor" style="vertical-align: middle; margin-right: 4px;">
                        <circle cx="8" cy="8" r="7" stroke="currentColor" fill="none" stroke-width="1.5"/>
                        <path d="M8 4v4l3 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/>
                    </svg>
                    ${video.duration}
                </div>
            </div>
        `;

        videoItem.addEventListener('click', () => {
            playVideo(video);
        });

        elements.videosGrid.appendChild(videoItem);
    });
}

// Render Workshops Section
function renderWorkshops(workshops) {
    if (!workshops || workshops.length === 0) {
        elements.workshopsSection.classList.add('hidden');
        return;
    }

    elements.workshopsSection.classList.remove('hidden');
    elements.workshopsList.innerHTML = '';

    // Check if this is the Bilan module (has links)
    const hasBilanLinks = workshops.some(w => w.link);

    // Use grid for Bilan module, list for others
    if (hasBilanLinks) {
        elements.workshopsList.style.display = 'grid';
        elements.workshopsList.style.gridTemplateColumns = 'repeat(auto-fit, minmax(300px, 1fr))';
        elements.workshopsList.style.gap = 'var(--spacing-lg)';
    } else {
        elements.workshopsList.style.display = 'flex';
        elements.workshopsList.style.flexDirection = 'column';
        elements.workshopsList.style.gap = 'var(--spacing-md)';
    }

    workshops.forEach(workshop => {
        const workshopItem = document.createElement('div');
        workshopItem.className = 'workshop-item';

        if (workshop.link) {
            // Bilan module style with prominent cards
            workshopItem.style.minHeight = '250px';
            workshopItem.style.display = 'flex';
            workshopItem.style.flexDirection = 'column';

            workshopItem.innerHTML = `
                <div class="workshop-title" style="margin-bottom: 1rem;">
                    <span style="font-size: 2.5rem;">${workshop.icon || '📋'}</span>
                    <span>${workshop.title}</span>
                </div>
                <p class="workshop-description" style="flex: 1; margin-bottom: 1rem;">${workshop.description}</p>
                <a href="${workshop.link}" class="btn btn-primary" style="display: inline-flex; align-items: center; gap: 0.5rem; font-size: 1rem; align-self: flex-start;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                        <path d="M13 16L18 12M18 12L13 8M18 12H6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                    Accéder
                </a>
            `;
        } else {
            // Regular workshop style
            const workshopIcon = getIcon('workshop', '32px');
            workshopItem.innerHTML = `
                <div class="workshop-title">
                    <div style="width: 32px; height: 32px; color: var(--primary-blue);">
                        ${workshopIcon}
                    </div>
                    <span>${workshop.title}</span>
                </div>
                <p class="workshop-description">${workshop.description}</p>
            `;

            workshopItem.addEventListener('click', () => {
                markContentViewed(workshop.id);
                checkModuleCompletion();
            });
        }

        elements.workshopsList.appendChild(workshopItem);
    });
}

// Play Video (Demo functionality)
function playVideo(video) {
    markContentViewed(video.id);
    checkModuleCompletion();

    alert(`🎥 Lecture de la vidéo: "${video.title}"\n\nDurée: ${video.duration}\n\n(Dans une version complète, la vidéo serait lue ici)`);
}

// Mark content as viewed
function markContentViewed(contentId) {
    AppState.viewedContent.add(contentId);
    saveState();
}

// Check if module is completed
function checkModuleCompletion() {
    if (!AppState.currentModule) return;

    const module = AppState.currentModule;
    const content = module.content;

    let allViewed = true;

    // Check videos
    if (content.videos) {
        for (const video of content.videos) {
            if (!AppState.viewedContent.has(video.id)) {
                allViewed = false;
                break;
            }
        }
    }

    // Check workshops
    if (allViewed && content.workshops) {
        for (const workshop of content.workshops) {
            if (!AppState.viewedContent.has(workshop.id)) {
                allViewed = false;
                break;
            }
        }
    }

    if (allViewed && !AppState.completedModules.has(module.id)) {
        AppState.completedModules.add(module.id);
        saveState();
        updateProgress();

        // Show completion message
        setTimeout(() => {
            alert(`🎉 Félicitations !\n\nVous avez terminé le module: "${module.title}"`);
        }, 300);
    }
}

// Update Progress Bar
function updateProgress() {
    if (!AppState.currentRole) {
        elements.progressFill.style.width = '0%';
        elements.progressText.textContent = '0%';
        return;
    }

    const modules = AppState.currentRole === 'patient' ? patientModules : caregiverModules;
    const totalModules = modules.length;
    const completedCount = Array.from(AppState.completedModules).filter(id =>
        modules.some(m => m.id === id)
    ).length;

    const percentage = totalModules > 0 ? Math.round((completedCount / totalModules) * 100) : 0;

    elements.progressFill.style.width = `${percentage}%`;
    elements.progressText.textContent = `${percentage}%`;
}

// Show View (hero, modules, or detail)
function showView(view) {
    elements.heroSection.classList.add('hidden');
    elements.mainContent.classList.add('hidden');
    elements.moduleDetail.classList.add('hidden');

    switch (view) {
        case 'hero':
            elements.heroSection.classList.remove('hidden');
            break;
        case 'modules':
            elements.mainContent.classList.remove('hidden');
            break;
        case 'detail':
            elements.moduleDetail.classList.remove('hidden');
            break;
    }
}

// Save State to LocalStorage
function saveState() {
    const state = {
        currentRole: AppState.currentRole,
        completedModules: Array.from(AppState.completedModules),
        viewedContent: Array.from(AppState.viewedContent)
    };
    localStorage.setItem('etpCharcotState', JSON.stringify(state));
}

// Load State from LocalStorage
function loadState() {
    const savedState = localStorage.getItem('etpCharcotState');
    if (savedState) {
        try {
            const state = JSON.parse(savedState);
            AppState.currentRole = state.currentRole;
            AppState.completedModules = new Set(state.completedModules || []);
            AppState.viewedContent = new Set(state.viewedContent || []);
        } catch (e) {
            console.error('Error loading state:', e);
        }
    }
}

// Header scroll effect
let lastScroll = 0;
window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    const header = document.getElementById('header');

    if (currentScroll > 100) {
        header.style.boxShadow = 'var(--shadow-md)';
    } else {
        header.style.boxShadow = 'none';
    }

    lastScroll = currentScroll;
});

// Add entrance animations
const animateOnScroll = () => {
    const elements = document.querySelectorAll('.module-card, .role-card');
    elements.forEach((el, index) => {
        const rect = el.getBoundingClientRect();
        const isVisible = rect.top < window.innerHeight - 100;

        if (isVisible) {
            setTimeout(() => {
                el.style.animation = `fadeInUp 0.6s ease forwards`;
            }, index * 100);
        }
    });
};

window.addEventListener('scroll', animateOnScroll);
window.addEventListener('load', animateOnScroll);

// Initialize the application when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
