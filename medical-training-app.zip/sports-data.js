// Sports Activities Data
const sportsActivities = [
    {
        id: 1,
        name: "Marcher",
        description: "Se déplacer à pied à un rythme normal",
        emoji: "🚶"
    },
    {
        id: 2,
        name: "Jardiner",
        description: "Entretenir son jardin et s'occuper des plantes",
        emoji: "🌱"
    },
    {
        id: 3,
        name: "Courir",
        description: "Course à pied, jogging",
        emoji: "🏃"
    },
    {
        id: 4,
        name: "Regarder la télévision",
        description: "Activité sédentaire devant la TV",
        emoji: "📺"
    },
    {
        id: 5,
        name: "Danser",
        description: "Bouger sur de la musique",
        emoji: "💃"
    },
    {
        id: 6,
        name: "Manger",
        description: "Prendre ses repas",
        emoji: "🍽️"
    },
    {
        id: 7,
        name: "Lire",
        description: "Lecture de livres, magazines",
        emoji: "📖"
    },
    {
        id: 8,
        name: "Faire le ménage",
        description: "Entretien de la maison",
        emoji: "🧹"
    },
    {
        id: 9,
        name: "Promener le chien",
        description: "Sortir avec son animal de compagnie",
        emoji: "🐕"
    },
    {
        id: 10,
        name: "Boire",
        description: "S'hydrater, boire de l'eau",
        emoji: "💧"
    },
    {
        id: 11,
        name: "Monter les escaliers",
        description: "Utiliser les escaliers plutôt que l'ascenseur",
        emoji: "🪜"
    },
    {
        id: 12,
        name: "Prendre l'ascenseur",
        description: "Utiliser l'ascenseur",
        emoji: "🛗"
    },
    {
        id: 13,
        name: "Jouer au foot",
        description: "Pratiquer le football",
        emoji: "⚽"
    },
    {
        id: 14,
        name: "Faire du shopping",
        description: "Faire les courses, achats",
        emoji: "🛍️"
    },
    {
        id: 15,
        name: "Transpirer",
        description: "Activité physique intense",
        emoji: "💦"
    },
    {
        id: 16,
        name: "Piscine",
        description: "Nager, activités aquatiques",
        emoji: "🏊"
    }
];
