// Application State
let currentIndex = 0;
let usefulActivities = [];
let notUsefulActivities = [];
let isDragging = false;
let startX = 0;
let currentX = 0;

// DOM Elements
const welcomeScreen = document.getElementById('welcome-screen');
const swipeSection = document.getElementById('swipe-section');
const resultsSection = document.getElementById('results-section');
const cardContainer = document.getElementById('card-container');
const progressText = document.getElementById('progress-text');
const progressFill = document.getElementById('progress-fill');
const startBtn = document.getElementById('start-btn');
const notUsefulBtn = document.getElementById('not-useful-btn');
const usefulBtn = document.getElementById('useful-btn');
const restartBtn = document.getElementById('restart-btn');
const usefulList = document.getElementById('useful-list');
const notUsefulList = document.getElementById('not-useful-list');

// Initialize
startBtn.addEventListener('click', startEvaluation);
notUsefulBtn.addEventListener('click', () => handleChoice(false));
usefulBtn.addEventListener('click', () => handleChoice(true));
restartBtn.addEventListener('click', restart);

function startEvaluation() {
    welcomeScreen.classList.add('hidden');
    swipeSection.classList.remove('hidden');
    loadCard();
}

function loadCard() {
    if (currentIndex >= sportsActivities.length) {
        showResults();
        return;
    }

    const activity = sportsActivities[currentIndex];
    const card = createCard(activity);
    cardContainer.innerHTML = '';
    cardContainer.appendChild(card);

    updateProgress();
    setupCardListeners(card);
}

function createCard(activity) {
    const card = document.createElement('div');
    card.className = 'activity-card';
    card.innerHTML = `
        <div class="card-emoji">${activity.emoji}</div>
        <h2 class="card-name">${activity.name}</h2>
        <p class="card-description">${activity.description}</p>
    `;
    return card;
}

function setupCardListeners(card) {
    // Mouse events
    card.addEventListener('mousedown', handleDragStart);
    document.addEventListener('mousemove', handleDragMove);
    document.addEventListener('mouseup', handleDragEnd);

    // Touch events
    card.addEventListener('touchstart', handleDragStart);
    document.addEventListener('touchmove', handleDragMove);
    document.addEventListener('touchend', handleDragEnd);
}

function handleDragStart(e) {
    isDragging = true;
    const card = e.currentTarget;
    card.classList.add('swiping');

    startX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
}

function handleDragMove(e) {
    if (!isDragging) return;

    currentX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
    const diff = currentX - startX;

    const card = cardContainer.querySelector('.activity-card');
    if (card) {
        const rotation = diff / 20;
        card.style.transform = `translateX(${diff}px) rotate(${rotation}deg)`;

        // Visual feedback
        if (diff > 50) {
            card.style.borderColor = 'var(--accent-green)';
        } else if (diff < -50) {
            card.style.borderColor = 'var(--accent-red)';
        } else {
            card.style.borderColor = 'hsla(210, 50%, 85%, 0.6)';
        }
    }
}

function handleDragEnd(e) {
    if (!isDragging) return;

    isDragging = false;
    const diff = currentX - startX;
    const card = cardContainer.querySelector('.activity-card');

    if (card) {
        card.classList.remove('swiping');

        if (Math.abs(diff) > 100) {
            // Swipe detected
            handleChoice(diff > 0);
        } else {
            // Reset position
            card.style.transform = '';
            card.style.borderColor = '';
        }
    }
}

function handleChoice(isUseful) {
    const activity = sportsActivities[currentIndex];
    const card = cardContainer.querySelector('.activity-card');

    if (isUseful) {
        usefulActivities.push(activity);
        if (card) {
            card.classList.add('swipe-right');
        }
    } else {
        notUsefulActivities.push(activity);
        if (card) {
            card.classList.add('swipe-left');
        }
    }

    currentIndex++;

    setTimeout(() => {
        loadCard();
    }, 300);
}

function updateProgress() {
    const total = sportsActivities.length;
    const percentage = (currentIndex / total) * 100;
    progressText.textContent = `${currentIndex}/${total}`;
    progressFill.style.width = `${percentage}%`;
}

function showResults() {
    swipeSection.classList.add('hidden');
    resultsSection.classList.remove('hidden');

    // Clear lists
    usefulList.innerHTML = '';
    notUsefulList.innerHTML = '';

    // Populate useful activities
    if (usefulActivities.length === 0) {
        usefulList.innerHTML = '<p style="color: var(--text-muted); padding: var(--spacing-md);">Aucune activité sélectionnée</p>';
    } else {
        usefulActivities.forEach(activity => {
            const item = createResultItem(activity);
            usefulList.appendChild(item);
        });
    }

    // Populate not useful activities
    if (notUsefulActivities.length === 0) {
        notUsefulList.innerHTML = '<p style="color: var(--text-muted); padding: var(--spacing-md);">Aucune activité sélectionnée</p>';
    } else {
        notUsefulActivities.forEach(activity => {
            const item = createResultItem(activity);
            notUsefulList.appendChild(item);
        });
    }
}

function createResultItem(activity) {
    const item = document.createElement('div');
    item.className = 'result-item';
    item.innerHTML = `
        <span class="result-item-emoji">${activity.emoji}</span>
        <span class="result-item-name">${activity.name}</span>
    `;
    return item;
}

function restart() {
    currentIndex = 0;
    usefulActivities = [];
    notUsefulActivities = [];

    resultsSection.classList.add('hidden');
    welcomeScreen.classList.remove('hidden');
}
