// Medical professions data for assessment
const professions = [
    { name: 'KINÉSITHÉRAPEUTE', icon: '🏃‍♂️', description: 'Spécialiste de la rééducation motrice et respiratoire' },
    { name: 'ERGOTHÉRAPEUTE', icon: '🛠️', description: 'Adaptation de l\'environnement et maintien de l\'autonomie' },
    { name: 'PSYCHOLOGUE', icon: '💭', description: 'Soutien psychologique pour le patient et les proches' },
    { name: 'MÉDECIN', icon: '👨‍⚕️', description: 'Suivi médical et coordination des soins' },
    { name: 'ORTHOPHONISTE', icon: '🗣️', description: 'Rééducation de la déglutition et de la parole' },
    { name: 'ENSEIGNANT EN ACTIVITÉ PHYSIQUE ADAPTÉE (EAPA)', icon: '⚽', description: 'Maintien de l\'activité physique adaptée' },
    { name: 'DIÉTÉTICIENNE', icon: '🥗', description: 'Adaptation nutritionnelle et conseils alimentaires' },
    { name: 'INFIRMIÈRE', icon: '💉', description: 'Soins quotidiens et surveillance médicale' },
    { name: 'HYPNOTHÉRAPEUTE', icon: '😌', description: 'Gestion de la douleur et relaxation' },
    { name: 'MAGNÉTISEUR', icon: '🧲', description: 'Approche complémentaire de bien-être' },
    { name: 'SECRÉTAIRE', icon: '💼', description: 'Support administratif et coordination' },
    { name: 'COACH SPORTIF', icon: '🏋️', description: 'Entraînement physique personnalisé' },
    { name: 'ORTHOPROTHÉSISTE', icon: '🦾', description: 'Conception d\'appareillages et d\'aides techniques' },
    { name: 'DENTISTE', icon: '🦷', description: 'Soins dentaires et hygiène bucco-dentaire' },
    { name: 'NATUROPATHE', icon: '🌿', description: 'Approche naturelle du bien-être' },
    { name: 'SEXOLOGUE', icon: '💕', description: 'Accompagnement de la vie intime et affective' }
];

// Shuffle array
function shuffle(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// App state
let currentIndex = 0;
let shuffledProfessions = shuffle(professions);
let usefulProfessions = [];
let notUsefulProfessions = [];

// DOM elements
const swipeContainer = document.getElementById('swipeContainer');
const progressBar = document.getElementById('progressBar');
const actionButtons = document.getElementById('actionButtons');
const summaryContainer = document.getElementById('summaryContainer');
const usefulList = document.getElementById('usefulList');
const notUsefulList = document.getElementById('notUsefulList');
const restartBtn = document.getElementById('restartBtn');
const rejectBtn = document.getElementById('rejectBtn');
const acceptBtn = document.getElementById('acceptBtn');

// Create card element
function createCard(profession) {
    const card = document.createElement('div');
    card.className = 'profession-card';
    card.innerHTML = `
        <div class="swipe-indicator left">NON</div>
        <div class="swipe-indicator right">OUI</div>
        <div class="card-icon">${profession.icon}</div>
        <h2 class="card-title">${profession.name}</h2>
        <p class="card-description">${profession.description}</p>
    `;
    return card;
}

// Update progress bar
function updateProgress() {
    const progress = ((currentIndex) / professions.length) * 100;
    progressBar.style.width = `${progress}%`;
}

// Show next card
function showNextCard() {
    if (currentIndex < shuffledProfessions.length) {
        const card = createCard(shuffledProfessions[currentIndex]);
        swipeContainer.appendChild(card);
        setupCardDrag(card);
        updateProgress();
    } else {
        showSummary();
    }
}

// Setup card dragging
function setupCardDrag(card) {
    let startX = 0;
    let currentX = 0;
    let isDragging = false;

    const leftIndicator = card.querySelector('.swipe-indicator.left');
    const rightIndicator = card.querySelector('.swipe-indicator.right');

    function handleStart(e) {
        isDragging = true;
        startX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
        card.classList.add('dragging');
    }

    function handleMove(e) {
        if (!isDragging) return;

        e.preventDefault();
        currentX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
        const deltaX = currentX - startX;
        const rotation = deltaX * 0.1;

        card.style.transform = `translateX(${deltaX}px) rotate(${rotation}deg)`;

        // Show indicators based on swipe direction
        if (Math.abs(deltaX) > 50) {
            if (deltaX < 0) {
                leftIndicator.style.opacity = Math.min(Math.abs(deltaX) / 100, 1);
                rightIndicator.style.opacity = 0;
            } else {
                rightIndicator.style.opacity = Math.min(deltaX / 100, 1);
                leftIndicator.style.opacity = 0;
            }
        } else {
            leftIndicator.style.opacity = 0;
            rightIndicator.style.opacity = 0;
        }
    }

    function handleEnd(e) {
        if (!isDragging) return;
        isDragging = false;

        const deltaX = currentX - startX;

        card.classList.remove('dragging');

        if (Math.abs(deltaX) > 100) {
            // Swipe detected
            if (deltaX < 0) {
                swipeLeft(card);
            } else {
                swipeRight(card);
            }
        } else {
            // Return to center
            card.style.transform = '';
            leftIndicator.style.opacity = 0;
            rightIndicator.style.opacity = 0;
        }
    }

    // Mouse events
    card.addEventListener('mousedown', handleStart);
    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleEnd);

    // Touch events
    card.addEventListener('touchstart', handleStart, { passive: false });
    document.addEventListener('touchmove', handleMove, { passive: false });
    document.addEventListener('touchend', handleEnd);
}

// Swipe left (not useful)
function swipeLeft(card) {
    card.classList.add('swipe-left');
    notUsefulProfessions.push(shuffledProfessions[currentIndex]);
    setTimeout(() => {
        card.remove();
        currentIndex++;
        showNextCard();
    }, 400);
}

// Swipe right (useful)
function swipeRight(card) {
    card.classList.add('swipe-right');
    usefulProfessions.push(shuffledProfessions[currentIndex]);
    setTimeout(() => {
        card.remove();
        currentIndex++;
        showNextCard();
    }, 400);
}

// Button actions
rejectBtn.addEventListener('click', () => {
    const card = document.querySelector('.profession-card');
    if (card && !card.classList.contains('swipe-left') && !card.classList.contains('swipe-right')) {
        swipeLeft(card);
    }
});

acceptBtn.addEventListener('click', () => {
    const card = document.querySelector('.profession-card');
    if (card && !card.classList.contains('swipe-left') && !card.classList.contains('swipe-right')) {
        swipeRight(card);
    }
});

// Show summary
function showSummary() {
    swipeContainer.style.display = 'none';
    actionButtons.style.display = 'none';
    summaryContainer.classList.remove('hidden');

    // Populate useful professions
    usefulList.innerHTML = '';
    if (usefulProfessions.length > 0) {
        usefulProfessions.forEach((profession, index) => {
            const item = document.createElement('div');
            item.className = 'summary-item useful';
            item.style.animationDelay = `${index * 0.1}s`;
            item.innerHTML = `
                <div class="summary-item-icon">${profession.icon}</div>
                <div>
                    <div class="summary-item-name">${profession.name}</div>
                    <div class="summary-item-description">${profession.description}</div>
                </div>
            `;
            usefulList.appendChild(item);
        });
    } else {
        usefulList.innerHTML = '<p style="color: var(--text-secondary); padding: 1rem;">Aucun professionnel sélectionné</p>';
    }

    // Populate not useful professions
    notUsefulList.innerHTML = '';
    if (notUsefulProfessions.length > 0) {
        notUsefulProfessions.forEach((profession, index) => {
            const item = document.createElement('div');
            item.className = 'summary-item not-useful';
            item.style.animationDelay = `${index * 0.1}s`;
            item.innerHTML = `
                <div class="summary-item-icon">${profession.icon}</div>
                <div>
                    <div class="summary-item-name">${profession.name}</div>
                    <div class="summary-item-description">${profession.description}</div>
                </div>
            `;
            notUsefulList.appendChild(item);
        });
    } else {
        notUsefulList.innerHTML = '<p style="color: var(--text-secondary); padding: 1rem;">Aucun professionnel sélectionné</p>';
    }
}

// Restart app
restartBtn.addEventListener('click', () => {
    currentIndex = 0;
    shuffledProfessions = shuffle(professions);
    usefulProfessions = [];
    notUsefulProfessions = [];

    summaryContainer.classList.add('hidden');
    swipeContainer.style.display = 'block';
    actionButtons.style.display = 'flex';

    progressBar.style.width = '0%';

    showNextCard();
});

// Initialize app
showNextCard();
