// Activities data
const activities = [
    { name: 'MARCHER', icon: '🚶', description: 'Activité physique douce et accessible' },
    { name: 'JARDINER', icon: '🌱', description: 'Activité manuelle en plein air' },
    { name: 'COURIR', icon: '🏃', description: 'Exercice cardiovasculaire intense' },
    { name: 'REGARDER LA TÉLÉVISION', icon: '📺', description: 'Activité de détente et divertissement' },
    { name: 'DANSER', icon: '💃', description: 'Mouvement rythmique et expression corporelle' },
    { name: 'MANGER', icon: '🍽️', description: 'Alimentation et nutrition' },
    { name: 'LIRE', icon: '📖', description: 'Stimulation cognitive et relaxation' },
    { name: 'FAIRE LE MÉNAGE', icon: '🧹', description: 'Tâches domestiques quotidiennes' },
    { name: 'PROMENER LE CHIEN', icon: '🐕', description: 'Activité extérieure avec animal' },
    { name: 'BOIRE', icon: '💧', description: 'Hydratation régulière' },
    { name: 'MONTER LES ESCALIERS', icon: '🪜', description: 'Exercice physique vertical' },
    { name: 'PRENDRE L\'ASCENSEUR', icon: '🛗', description: 'Déplacement vertical assisté' },
    { name: 'JOUER AU FOOT', icon: '⚽', description: 'Sport collectif dynamique' },
    { name: 'FAIRE DU SHOPPING', icon: '🛍️', description: 'Sortie et activité sociale' },
    { name: 'TRANSPIRER', icon: '💦', description: 'Effort physique intense' },
    { name: 'PISCINE', icon: '🏊', description: 'Activité aquatique' }
];

// Shuffle array
function shuffle(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// App state
let currentIndex = 0;
let shuffledActivities = shuffle(activities);
let usefulActivities = [];
let notUsefulActivities = [];

// DOM elements
const swipeContainer = document.getElementById('swipeContainer');
const progressBar = document.getElementById('progressBar');
const actionButtons = document.getElementById('actionButtons');
const summaryContainer = document.getElementById('summaryContainer');
const usefulList = document.getElementById('usefulList');
const notUsefulList = document.getElementById('notUsefulList');
const restartBtn = document.getElementById('restartBtn');
const rejectBtn = document.getElementById('rejectBtn');
const acceptBtn = document.getElementById('acceptBtn');

// Create card element
function createCard(activity) {
    const card = document.createElement('div');
    card.className = 'profession-card';
    card.innerHTML = `
        <div class="swipe-indicator left">NON</div>
        <div class="swipe-indicator right">OUI</div>
        <div class="card-icon">${activity.icon}</div>
        <h2 class="card-title">${activity.name}</h2>
    `;
    return card;
}

// Update progress bar
function updateProgress() {
    const progress = ((currentIndex) / activities.length) * 100;
    progressBar.style.width = `${progress}%`;
}

// Show next card
function showNextCard() {
    if (currentIndex < shuffledActivities.length) {
        const card = createCard(shuffledActivities[currentIndex]);
        swipeContainer.appendChild(card);
        setupCardDrag(card);
        updateProgress();
    } else {
        showSummary();
    }
}

// Setup card dragging
function setupCardDrag(card) {
    let startX = 0;
    let currentX = 0;
    let isDragging = false;

    const leftIndicator = card.querySelector('.swipe-indicator.left');
    const rightIndicator = card.querySelector('.swipe-indicator.right');

    function handleStart(e) {
        isDragging = true;
        startX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
        card.classList.add('dragging');
    }

    function handleMove(e) {
        if (!isDragging) return;

        e.preventDefault();
        currentX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
        const deltaX = currentX - startX;
        const rotation = deltaX * 0.1;

        card.style.transform = `translateX(${deltaX}px) rotate(${rotation}deg)`;

        // Show indicators based on swipe direction
        if (Math.abs(deltaX) > 50) {
            if (deltaX < 0) {
                leftIndicator.style.opacity = Math.min(Math.abs(deltaX) / 100, 1);
                rightIndicator.style.opacity = 0;
            } else {
                rightIndicator.style.opacity = Math.min(deltaX / 100, 1);
                leftIndicator.style.opacity = 0;
            }
        } else {
            leftIndicator.style.opacity = 0;
            rightIndicator.style.opacity = 0;
        }
    }

    function handleEnd(e) {
        if (!isDragging) return;
        isDragging = false;

        const deltaX = currentX - startX;

        card.classList.remove('dragging');

        if (Math.abs(deltaX) > 100) {
            // Swipe detected
            if (deltaX < 0) {
                swipeLeft(card);
            } else {
                swipeRight(card);
            }
        } else {
            // Return to center
            card.style.transform = '';
            leftIndicator.style.opacity = 0;
            rightIndicator.style.opacity = 0;
        }
    }

    // Mouse events
    card.addEventListener('mousedown', handleStart);
    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleEnd);

    // Touch events
    card.addEventListener('touchstart', handleStart, { passive: false });
    document.addEventListener('touchmove', handleMove, { passive: false });
    document.addEventListener('touchend', handleEnd);
}

// Swipe left (not useful)
function swipeLeft(card) {
    card.classList.add('swipe-left');
    notUsefulActivities.push(shuffledActivities[currentIndex]);
    setTimeout(() => {
        card.remove();
        currentIndex++;
        showNextCard();
    }, 400);
}

// Swipe right (useful)
function swipeRight(card) {
    card.classList.add('swipe-right');
    usefulActivities.push(shuffledActivities[currentIndex]);
    setTimeout(() => {
        card.remove();
        currentIndex++;
        showNextCard();
    }, 400);
}

// Button actions
rejectBtn.addEventListener('click', () => {
    const card = document.querySelector('.profession-card');
    if (card && !card.classList.contains('swipe-left') && !card.classList.contains('swipe-right')) {
        swipeLeft(card);
    }
});

acceptBtn.addEventListener('click', () => {
    const card = document.querySelector('.profession-card');
    if (card && !card.classList.contains('swipe-left') && !card.classList.contains('swipe-right')) {
        swipeRight(card);
    }
});

// Show summary
function showSummary() {
    swipeContainer.style.display = 'none';
    actionButtons.style.display = 'none';
    summaryContainer.classList.remove('hidden');

    // Populate useful activities
    usefulList.innerHTML = '';
    if (usefulActivities.length > 0) {
        usefulActivities.forEach((activity, index) => {
            const item = document.createElement('div');
            item.className = 'summary-item useful';
            item.style.animationDelay = `${index * 0.1}s`;
            item.innerHTML = `
                <div class="summary-item-icon">${activity.icon}</div>
                <div class="summary-item-name">${activity.name}</div>
            `;
            usefulList.appendChild(item);
        });
    } else {
        usefulList.innerHTML = '<p style="color: var(--text-secondary); padding: 1rem;">Aucune activité sélectionnée</p>';
    }

    // Populate not useful activities
    notUsefulList.innerHTML = '';
    if (notUsefulActivities.length > 0) {
        notUsefulActivities.forEach((activity, index) => {
            const item = document.createElement('div');
            item.className = 'summary-item not-useful';
            item.style.animationDelay = `${index * 0.1}s`;
            item.innerHTML = `
                <div class="summary-item-icon">${activity.icon}</div>
                <div class="summary-item-name">${activity.name}</div>
            `;
            notUsefulList.appendChild(item);
        });
    } else {
        notUsefulList.innerHTML = '<p style="color: var(--text-secondary); padding: 1rem;">Aucune activité sélectionnée</p>';
    }
}

// Restart app
restartBtn.addEventListener('click', () => {
    currentIndex = 0;
    shuffledActivities = shuffle(activities);
    usefulActivities = [];
    notUsefulActivities = [];

    summaryContainer.classList.add('hidden');
    swipeContainer.style.display = 'block';
    actionButtons.style.display = 'flex';

    progressBar.style.width = '0%';

    showNextCard();
});

// Initialize app
showNextCard();
