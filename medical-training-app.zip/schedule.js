// Schedule App - Weekly Calendar for Daily Activities
// Stores activities in localStorage

// App State
let activities = {};
let currentEditCell = null;

// Days of the week
const DAYS = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'];

// Time slots (8:00 to 00:00+)
const TIME_SLOTS = [
    '08h00', '09h00', '10h00', '11h00', '12h00', '13h00', '14h00',
    '15h00', '16h00', '17h00', '18h00', '19h00', '20h00', '21h00',
    '22h00', '23h00', '00h00+'
];

// DOM Elements
const calendarGrid = document.getElementById('calendar-grid');
const modal = document.getElementById('activity-modal');
const modalOverlay = document.getElementById('modal-overlay');
const modalClose = document.getElementById('modal-close');
const modalTitle = document.getElementById('modal-title');
const activityForm = document.getElementById('activity-form');
const activityName = document.getElementById('activity-name');
const activityCategory = document.getElementById('activity-category');
const activityDay = document.getElementById('activity-day');
const activityTime = document.getElementById('activity-time');
const deleteBtn = document.getElementById('delete-btn');
const cancelBtn = document.getElementById('cancel-btn');
const submitText = document.getElementById('submit-text');
const saveBtn = document.getElementById('save-btn');
const resetBtn = document.getElementById('reset-btn');

// Initialize calendar grid
function initializeCalendar() {
    TIME_SLOTS.forEach(time => {
        // Time column
        const timeCell = document.createElement('div');
        timeCell.className = 'calendar-time-cell';
        timeCell.textContent = time;
        calendarGrid.appendChild(timeCell);

        // Day columns
        DAYS.forEach(day => {
            const cell = document.createElement('div');
            cell.className = 'calendar-cell';
            cell.dataset.day = day;
            cell.dataset.time = time;
            cell.addEventListener('click', () => openModal(day, time, cell));
            calendarGrid.appendChild(cell);
        });
    });
}

// Load activities from localStorage
function loadActivities() {
    const saved = localStorage.getItem('weeklySchedule');
    if (saved) {
        activities = JSON.parse(saved);
        renderActivities();
    }
}

// Save activities to localStorage
function saveActivities() {
    localStorage.setItem('weeklySchedule', JSON.stringify(activities));
}

// Render activities on calendar
function renderActivities() {
    // Clear all cells
    document.querySelectorAll('.calendar-cell').forEach(cell => {
        cell.classList.remove('has-activity');
        cell.innerHTML = '';
        delete cell.dataset.category;
    });

    // Render each activity
    Object.keys(activities).forEach(key => {
        const activity = activities[key];
        const timeSlot = activity.timeSlot || activity.time; // Support both old and new format  
        const cell = document.querySelector(
            `.calendar-cell[data-day="${activity.day}"][data-time="${timeSlot}"]`
        );

        if (cell) {
            cell.classList.add('has-activity');
            cell.dataset.category = activity.category;

            const content = document.createElement('div');
            content.className = 'activity-content';
            content.innerHTML = `<strong>${activity.customTime || timeSlot}</strong><br>${activity.name}`;
            cell.appendChild(content);
        }
    });
}

// Open modal to add/edit activity
function openModal(day, time, cell) {
    currentEditCell = { day, time, cell };
    const key = `${day}-${time}`;
    const existingActivity = activities[key];

    if (existingActivity) {
        // Edit mode
        modalTitle.textContent = 'Modifier l\'activité';
        activityName.value = existingActivity.name;
        activityCategory.value = existingActivity.category;
        activityTime.value = existingActivity.customTime || time;
        deleteBtn.classList.remove('hidden');
        submitText.textContent = 'Modifier';
    } else {
        // Add mode
        modalTitle.textContent = 'Ajouter une activité';
        activityName.value = '';
        activityCategory.value = 'soin';
        activityTime.value = time; // Pre-fill but allow editing
        deleteBtn.classList.add('hidden');
        submitText.textContent = 'Ajouter';
    }

    activityDay.value = day;
    modal.classList.remove('hidden');

    // Focus on name input
    setTimeout(() => activityName.focus(), 100);
}

// Close modal
function closeModal() {
    modal.classList.add('hidden');
    currentEditCell = null;
}

// Handle form submission
activityForm.addEventListener('submit', (e) => {
    e.preventDefault();

    if (!currentEditCell) return;

    const { day, time } = currentEditCell;
    const key = `${day}-${time}`;
    const customTime = activityTime.value.trim();

    // Validate time format (basic check)
    if (!customTime.match(/^\d{1,2}h\d{0,2}$/)) {
        alert('Format d\'heure invalide. Utilisez le format: XXhXX (ex: 7h30, 14h00)');
        return;
    }

    activities[key] = {
        day,
        timeSlot: time, // Original time slot for positioning
        customTime: customTime, // User's custom time
        name: activityName.value.trim(),
        category: activityCategory.value
    };

    saveActivities();
    renderActivities();
    closeModal();

    // Show feedback
    showFeedback('Activité enregistrée ✓');
});

// Delete activity
deleteBtn.addEventListener('click', () => {
    if (!currentEditCell) return;

    const { day, time } = currentEditCell;
    const key = `${day}-${time}`;

    if (confirm('Êtes-vous sûr de vouloir supprimer cette activité ?')) {
        delete activities[key];
        saveActivities();
        renderActivities();
        closeModal();
        showFeedback('Activité supprimée ✓');
    }
});

// Modal close handlers
modalClose.addEventListener('click', closeModal);
cancelBtn.addEventListener('click', closeModal);
modalOverlay.addEventListener('click', closeModal);

// Escape key to close modal
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
        closeModal();
    }
});

// Save button (manual save with feedback)
saveBtn.addEventListener('click', () => {
    saveActivities();
    showFeedback('Planning sauvegardé ✓');
});

// Reset button
resetBtn.addEventListener('click', () => {
    if (confirm('Êtes-vous sûr de vouloir réinitialiser tout le planning ? Cette action est irréversible.')) {
        activities = {};
        saveActivities();
        renderActivities();
        showFeedback('Planning réinitialisé ✓');
    }
});

// Show feedback message
function showFeedback(message) {
    const feedback = document.createElement('div');
    feedback.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: linear-gradient(135deg, #4ECDC4, #44A08D);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 12px;
        font-weight: 600;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        z-index: 2000;
        animation: slideIn 0.3s ease, fadeOut 0.3s ease 2.5s;
    `;
    feedback.textContent = message;
    document.body.appendChild(feedback);

    setTimeout(() => {
        feedback.remove();
    }, 3000);
}

// Initialize app
initializeCalendar();
loadActivities();
