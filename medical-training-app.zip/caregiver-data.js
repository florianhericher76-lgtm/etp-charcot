// Caregiver Module Data
const caregiverModules = [
    {
        id: 0,
        number: "BILAN",
        title: "Bilan Éducatif",
        objective: "Évaluer vos besoins et réfléchir sur votre parcours d'aidant",
        skills: [
            "Identifier les professionnels utiles pour accompagner votre proche",
            "Réfléchir sur vos ressentis et besoins en tant qu'aidant",
            "Faire le point sur votre rôle et vos limites"
        ],
        icon: "📋",
        color: "hsl(280, 60%, 55%)",
        content: {
            workshops: [
                {
                    id: "cw0-1",
                    title: "Tinder métier",
                    description: "Identifiez les professionnels qui vous semblent utiles pour la prise en charge de la SLA (système de swipe interactif)",
                    icon: "👨‍⚕️",
                    link: "assessment.html"
                },
                {
                    id: "cw0-2",
                    title: "Ma Boussole ETP",
                    description: "Placez librement vos réflexions sur la boussole : ce qui vous aide, ce qui est difficile, ce que vous redoutez, ce que vous voulez préserver",
                    icon: "🧭",
                    link: "compass.html"
                },
                {
                    id: "cw0-3",
                    title: "Le jeu des cartes",
                    description: "Sélectionnez 3 émotions + 3 difficultés parmi 22 cartes (6 cartes au total)",
                    icon: "🃏",
                    link: "emotions.html"
                },
                {
                    id: "cw0-4",
                    title: "Votre journée type",
                    description: "Planifiez et visualisez vos activités hebdomadaires sur un calendrier interactif",
                    icon: "📅",
                    link: "schedule.html"
                },
                {
                    id: "cw0-5",
                    title: "Parcours de vie",
                    description: "Tracez l'évolution du bien-être de votre proche avant et après le diagnostic",
                    icon: "📈",
                    link: "lifejourney.html"
                }
            ]
        }
    },
    {
        id: 1,
        number: "MODULE 1",
        title: "Présentation de la maladie",
        objective: "Comprendre la maladie et son évolution",
        skills: [
            "Expliquer les mécanismes de la maladie",
            "Identifier les symptômes moteurs et respiratoires",
            "Comprendre les limites des traitements actuels"
        ],
        icon: "📚",
        color: "hsl(210, 70%, 50%)",
        content: {
            videos: [
                {
                    id: "cv1-1",
                    title: "Présentation globale de la maladie",
                    duration: "12:30",
                    thumbnail: "📹"
                },
                {
                    id: "cv1-2",
                    title: "Présentation des troubles",
                    duration: "15:45",
                    thumbnail: "📹"
                },
                {
                    id: "cv1-3",
                    title: "Les différents types de prise en charge",
                    duration: "18:20",
                    thumbnail: "📹"
                }
            ]
        }
    },
    {
        id: 2,
        number: "MODULE 2",
        title: "Communication et parole",
        objective: "Communiquer avec un patient possédant des troubles",
        skills: [
            "Connaître les outils de communication",
            "Comprendre et décoder le langage non-verbal",
            "Développer une communication patiente et bienveillante"
        ],
        icon: "🗨️",
        color: "hsl(180, 65%, 45%)",
        content: {
            workshops: [
                {
                    id: "cw2-1",
                    title: "Entretien individuel avec l'orthophoniste",
                    description: "Session personnalisée pour comprendre les troubles de communication et apprendre à adapter sa communication",
                    icon: "👨‍⚕️"
                },
                {
                    id: "cw2-2",
                    title: "Ateliers communication (langage des signes et communication non-verbale)",
                    description: "Apprentissage pratique des méthodes de communication alternatives",
                    icon: "🤟"
                },
                {
                    id: "cw2-3",
                    title: "Groupe de parole",
                    description: "Échange d'expériences et de stratégies entre aidants",
                    icon: "💬"
                }
            ]
        }
    },
    {
        id: 3,
        number: "MODULE 3",
        title: "Gestion du quotidien",
        objective: "Accompagner son proche dans la perte d'autonomie et garantir son confort",
        skills: [
            "Adapter l'aide au quotidien",
            "Savoir utiliser l'équipement nécessaire",
            "Encourager l'autonomie restante",
            "Identifier les risques domestiques",
            "Participer à la planification des aménagements"
        ],
        icon: "🏠",
        color: "hsl(150, 60%, 50%)",
        content: {
            workshops: [
                {
                    id: "cw3-1",
                    title: "Atelier diététique",
                    description: "Conseils nutritionnels et adaptation des repas selon les besoins du patient",
                    icon: "🥗"
                },
                {
                    id: "cw3-2",
                    title: "Tutoriels sur l'utilisation des équipements (fauteuil, ...)",
                    description: "Formation pratique à l'utilisation des équipements médicaux et d'aide à la mobilité",
                    icon: "♿"
                },
                {
                    id: "cw3-3",
                    title: "Ateliers d'organisation",
                    description: "Planification et organisation du quotidien pour optimiser le confort et la sécurité",
                    icon: "📋"
                }
            ]
        }
    },
    {
        id: 4,
        number: "MODULE 4",
        title: "Gestion des émotions",
        objective: "Préserver son équilibre et limiter la fatigue",
        skills: [
            "Reconnaître les signes de fatigue et de surcharge",
            "Mettre en place des stratégies de relaxation"
        ],
        icon: "🧘‍♀️",
        color: "hsl(270, 60%, 60%)",
        content: {
            workshops: [
                {
                    id: "cw4-1",
                    title: "Signaux d'alarmes",
                    description: "Identifier les signes précurseurs de l'épuisement de l'aidant et apprendre à demander de l'aide",
                    icon: "⚠️"
                },
                {
                    id: "cw4-2",
                    title: "Respiration et relaxation",
                    description: "Techniques de gestion du stress et de relaxation pour préserver sa santé mentale",
                    icon: "🌬️"
                }
            ]
        }
    },
    {
        id: 5,
        number: "MODULE 5",
        title: "Fin de vie et deuil",
        objective: "Favoriser un accompagnement respectueux et digne",
        skills: [
            "Comprendre les enjeux de la fin de vie",
            "Connaître les droits du patient",
            "Mobiliser les aides personnelles et stratégies d'adaptation",
            "Comprendre les différentes étapes du deuil",
            "Maintenir le lien social et familial malgré la souffrance"
        ],
        icon: "🕊️",
        color: "hsl(200, 50%, 55%)",
        content: {
            videos: [
                {
                    id: "cv5-1",
                    title: "Droits du patient",
                    duration: "14:20",
                    thumbnail: "📹"
                },
                {
                    id: "cv5-2",
                    title: "Vidéo étapes du deuil",
                    duration: "16:45",
                    thumbnail: "📹"
                }
            ],
            workshops: [
                {
                    id: "cw5-1",
                    title: "Enjeux de la fin de vie",
                    description: "Comprendre et anticiper les questions liées à la fin de vie",
                    icon: "💭"
                },
                {
                    id: "cw5-2",
                    title: "Groupe de parole",
                    description: "Espace bienveillant pour partager son vécu et recevoir du soutien",
                    icon: "🤝"
                }
            ]
        }
    }
];
