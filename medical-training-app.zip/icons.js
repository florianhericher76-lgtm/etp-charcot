// SVG Icons Library
const Icons = {
    // Role Icons
    patient: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="24" cy="24" r="23" fill="url(#grad-patient)" stroke="white" stroke-width="2"/>
        <circle cx="24" cy="18" r="6" fill="white"/>
        <path d="M14 36c0-5.5 4.5-10 10-10s10 4.5 10 10" fill="white"/>
        <rect x="21" y="12" width="6" height="2" rx="1" fill="hsl(210, 70%, 50%)"/>
        <rect x="23" y="10" width="2" height="6" rx="1" fill="hsl(210, 70%, 50%)"/>
        <defs>
            <linearGradient id="grad-patient" x1="0" y1="0" x2="48" y2="48">
                <stop offset="0%" style="stop-color:hsl(210, 80%, 60%)"/>
                <stop offset="100%" style="stop-color:hsl(180, 70%, 55%)"/>
            </linearGradient>
        </defs>
    </svg>`,

    caregiver: `<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="24" cy="24" r="23" fill="url(#grad-caregiver)" stroke="white" stroke-width="2"/>
        <path d="M24 34c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm-6-8c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm12 0c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z" fill="white" opacity="0.3"/>
        <path d="M24 16l-7 7h4v8h6v-8h4z" fill="white"/>
        <defs>
            <linearGradient id="grad-caregiver" x1="0" y1="0" x2="48" y2="48">
                <stop offset="0%" style="stop-color:hsl(180, 75%, 55%)"/>
                <stop offset="100%" style="stop-color:hsl(150, 65%, 60%)"/>
            </linearGradient>
        </defs>
    </svg>`,

    // Module Icons  
    medical: `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="30" fill="url(#grad-medical)"/>
        <rect x="28" y="20" width="8" height="24" rx="2" fill="white"/>
        <rect x="20" y="28" width="24" height="8" rx="2" fill="white"/>
        <defs>
            <linearGradient id="grad-medical" x1="0" y1="0" x2="64" y2="64">
                <stop offset="0%" style="stop-color:hsl(210, 80%, 65%)"/>
                <stop offset="100%" style="stop-color:hsl(180, 70%, 60%)"/>
            </linearGradient>
        </defs>
    </svg>`,

    communication: `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="30" fill="url(#grad-comm)"/>
        <path d="M20 24c0-4 3-7 7-7h10c4 0 7 3 7 7v12c0 4-3 7-7 7h-4l-6 5v-5h-0c-4 0-7-3-7-7z" fill="white"/>
        <path d="M26 28h12M26 33h8" stroke="hsl(180, 70%, 50%)" stroke-width="2" stroke-linecap="round"/>
        <defs>
            <linearGradient id="grad-comm" x1="0" y1="0" x2="64" y2="64">
                <stop offset="0%" style="stop-color:hsl(180, 75%, 60%)"/>
                <stop offset="100%" style="stop-color:hsl(150, 70%, 65%)"/>
            </linearGradient>
        </defs>
    </svg>`,

    home: `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="30" fill="url(#grad-home)"/>
        <path d="M32 18l-14 12v16c0 2 1 3 3 3h22c2 0 3-1 3-3V30z" fill="white"/>
        <circle cx="32" cy="35" r="4" fill="hsl(150, 65%, 55%)"/>
        <defs>
            <linearGradient id="grad-home" x1="0" y1="0" x2="64" y2="64">
                <stop offset="0%" style="stop-color:hsl(150, 70%, 65%)"/>
                <stop offset="100%" style="stop-color:hsl(120, 60%, 60%)"/>
            </linearGradient>
        </defs>
    </svg>`,

    meditation: `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="30" fill="url(#grad-meditation)"/>
        <circle cx="32" cy="24" r="6" fill="white"/>
        <path d="M20 42c0-2 1.5-4 3-5 1.5-1 3-2 5-2h8c2 0 3.5 1 5 2 1.5 1 3 3 3 5" stroke="white" stroke-width="3" stroke-linecap="round"/>
        <circle cx="20" cy="30" r="3" fill="white" opacity="0.6"/>
        <circle cx="44" cy="30" r="3" fill="white" opacity="0.6"/>
        <defs>
            <linearGradient id="grad-meditation" x1="0" y1="0" x2="64" y2="64">
                <stop offset="0%" style="stop-color:hsl(270, 70%, 70%)"/>
                <stop offset="100%" style="stop-color:hsl(290, 65%, 65%)"/>
            </linearGradient>
        </defs>
    </svg>`,

    peace: `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="30" fill="url(#grad-peace)"/>
        <path d="M28 22c-2 2-2 5-1 7l8 8c2 1 5 1 7-1 2-2 2-5 1-7l-8-8c-2-1-5-1-7 1z" fill="white"/>
        <path d="M38 28l6-4M30 36l-4 6" stroke="white" stroke-width="2" stroke-linecap="round"/>
        <circle cx="24" cy="24" r="2" fill="white" opacity="0.7"/>
        <circle cx="40" cy="40" r="2" fill="white" opacity="0.7"/>
        <defs>
            <linearGradient id="grad-peace" x1="0" y1="0" x2="64" y2="64">
                <stop offset="0%" style="stop-color:hsl(200, 70%, 65%)"/>
                <stop offset="100%" style="stop-color:hsl(220, 60%, 70%)"/>
            </linearGradient>
        </defs>
    </svg>`,

    strength: `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="30" fill="url(#grad-strength)"/>
        <path d="M26 30h12v8h-12z" fill="white"/>
        <circle cx="26" cy="34" r="5" fill="white"/>
        <circle cx="38" cy="34" r="5" fill="white"/>
        <rect x="22" y="28" width="4" height="4" rx="1" fill="white"/>
        <rect x="38" y="28" width="4" height="4" rx="1" fill="white"/>
        <path d="M32 24v-4M28 26l-3-3M36 26l3-3" stroke="white" stroke-width="2" stroke-linecap="round"/>
        <defs>
            <linearGradient id="grad-strength" x1="0" y1="0" x2="64" y2="64">
                <stop offset="0%" style="stop-color:hsl(25, 85%, 65%)"/>
                <stop offset="100%" style="stop-color:hsl(15, 80%, 60%)"/>
            </linearGradient>
        </defs>
    </svg>`,

    // Content Icons
    video: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="2" y="4" width="20" height="16" rx="2" fill="currentColor" opacity="0.2"/>
        <path d="M10 8l6 4-6 4z" fill="currentColor"/>
    </svg>`,

    workshop: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2L2 7v10c0 5 10 9 10 9s10-4 10-9V7z" fill="currentColor" opacity="0.2"/>
        <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    </svg>`,

    checkmark: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="12" cy="12" r="10" fill="hsl(150, 70%, 50%)"/>
        <path d="M8 12l2 2 4-4" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`,

    play: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="12" cy="12" r="10" fill="white"/>
        <path d="M10 8l6 4-6 4z" fill="currentColor"/>
    </svg>`
};

// Function to get icon HTML
function getIcon(iconName, size = '64px') {
    const icon = Icons[iconName] || Icons.medical;
    return `<div class="icon-wrapper" style="width: ${size}; height: ${size};">${icon}</div>`;
}

// Module icon mapping
const moduleIcons = {
    patient: {
        1: 'medical',
        2: 'strength',
        3: 'meditation',
        4: 'communication',
        5: 'peace'
    },
    caregiver: {
        1: 'medical',
        2: 'communication',
        3: 'home',
        4: 'meditation',
        5: 'peace'
    }
};

function getModuleIcon(role, moduleId, size = '64px') {
    const iconName = moduleIcons[role]?.[moduleId] || 'medical';
    return getIcon(iconName, size);
}
