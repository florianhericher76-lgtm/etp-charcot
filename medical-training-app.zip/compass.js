// Compass Application with Free Positioning and Predefined Words

// Predefined words by category (complete list from user's image)
const predefinedWords = {
    preserve: [
        "Mon conjoint / ma famille",
        "Mes proches",
        "L'équipe soignante",
        "Les aidants professionnels",
        "Mon kinésithérapeute",
        "Mon fauteuil / déambulateur",
        "Mon ergothérapeute / orthèse",
        "Les adaptations de la maison",
        "Mon lit",
        "Mon sommeil / insomnie",
        "Les rendez-vous réguliers",
        "Ma gestion de l'intimité",
        "Ma spiritualité",
        "Mon autonomie financière",
        "La musique",
        "Être écouté / respecté",
        "Les informations claires",
        "Me sentir en sécurité"
    ],
    fear: [
        "La fatigue",
        "L'impression de souffrir",
        "Avaler / s'étouffer",
        "Crier",
        "Écrire",
        "Me déplacer",
        "Intérêts",
        "M'habiller",
        "Me laver",
        "Sortir de chez moi",
        "Dormir",
        "La douleur",
        "La dépendance",
        "Perdre de l'aide",
        "Les démarches",
        "Le regard des autres",
        "Les rendez-vous",
        "L'attente"
    ],
    difficult: [
        "M'étouffer",
        "Souffrir",
        "Tomber",
        "Perdre la parole",
        "Perdre l'autonomie",
        "Être un poids",
        "Perdre la communication",
        "Ne plus pouvoir communiquer",
        "Ne plus manger",
        "La trachéotomie",
        "La gastrostomie",
        "Mourir",
        "Perdre le contrôle",
        "Être seul",
        "L'avenir",
        "L'inconnu",
        "La nuit"
    ],
    help: [
        "Mon entourage",
        "Les professionnels de santé",
        "Les aides techniques",
        "Le soutien psychologique",
        "L'écoute",
        "La communication",
        "Les traitements",
        "Les activités adaptées"
    ]
};

// State management
const compassState = {
    words: [] // Array of {id, text, x, y}
};

// DOM Elements
const compassCircle = document.getElementById('compassCircle');
const wordsContainer = document.getElementById('wordsContainer');
const inputModal = document.getElementById('inputModal');
const wordInput = document.getElementById('wordInput');
const saveBtn = document.getElementById('saveBtn');
const cancelBtn = document.getElementById('cancelBtn');
const printBtn = document.getElementById('print-btn');
const clearBtn = document.getElementById('clear-btn');
const predefinedWordsDiv = document.getElementById('predefinedWords');
const customWordBtn = document.getElementById('customWordBtn');

// Current click position
let pendingPosition = null;

// Initialize
function initCompass() {
    loadWords();
    renderAllWords();

    // Click on compass to add word
    compassCircle.addEventListener('click', handleCompassClick);

    // Modal buttons
    saveBtn.addEventListener('click', saveWord);
    cancelBtn.addEventListener('click', closeModal);
    wordInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            saveWord();
        }
    });

    customWordBtn.addEventListener('click', showCustomInput);

    // Action buttons
    printBtn.addEventListener('click', printCompass);
    clearBtn.addEventListener('click', clearAllWords);
}

// Handle click on compass circle
function handleCompassClick(e) {
    // Don't trigger if clicking on a word or center or label
    if (e.target.classList.contains('word-item') ||
        e.target.closest('.compass-center') ||
        e.target.closest('.word-item') ||
        e.target.closest('.compass-label')) {
        return;
    }

    const rect = compassCircle.getBoundingClientRect();
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    // Get click position relative to circle
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Calculate distance from center
    const dx = clickX - centerX;
    const dy = clickY - centerY;
    const distance = Math.sqrt(dx * dx + dy * dy);

    // Only allow clicks within the circle (but not too close to center)
    const radius = Math.min(centerX, centerY);
    if (distance < 60 || distance > radius - 20) {
        return; // Too close to center or outside circle
    }

    // Store position and open modal
    pendingPosition = {
        x: (clickX / rect.width) * 100, // Convert to percentage
        y: (clickY / rect.height) * 100
    };

    // Determine suggested category based on position
    const angle = Math.atan2(dy, dx) * (180 / Math.PI);
    const suggestedCategory = getCategoryFromAngle(angle);

    openModal(suggestedCategory);
}

// Get category from angle
function getCategoryFromAngle(angle) {
    // Normalize angle to 0-360
    const normalizedAngle = (angle + 360) % 360;

    if (normalizedAngle >= 315 || normalizedAngle < 45) return 'difficult'; // Right
    if (normalizedAngle >= 45 && normalizedAngle < 135) return 'fear'; // Bottom
    if (normalizedAngle >= 135 && normalizedAngle < 225) return 'preserve'; // Left
    return 'help'; // Top
}

// Open modal for text input
function openModal(suggestedCategory = 'help') {
    inputModal.classList.remove('hidden');
    wordInput.value = '';
    wordInput.style.display = 'none';
    predefinedWordsDiv.style.display = 'block';

    // Render predefined words for the suggested category
    renderPredefinedWords(suggestedCategory);
}

// Show custom input field
function showCustomInput() {
    wordInput.style.display = 'block';
    predefinedWordsDiv.style.display = 'none';
    wordInput.focus();
}

// Render predefined words
function renderPredefinedWords(category) {
    const words = predefinedWords[category] || [];

    predefinedWordsDiv.innerHTML = `
        <div class="category-title">${getCategoryLabel(category)}</div>
        <div class="words-grid">
            ${words.map(word => `
                <button class="word-choice-btn" onclick="selectPredefinedWord('${escapeForJs(word)}')">${escapeHtml(word)}</button>
            `).join('')}
        </div>
        <div style="text-align: center; margin-top: 1rem;">
            <button id="customWordBtn" class="btn btn-secondary" style="font-size: 0.9rem;">
                ✏️ Écrire un mot personnalisé
            </button>
        </div>
    `;

    // Re-attach event listener
    document.getElementById('customWordBtn').addEventListener('click', showCustomInput);
}

// Get category label
function getCategoryLabel(category) {
    const labels = {
        help: 'Ce qui m\'aide',
        difficult: 'Ce qui m\'est difficile',
        fear: 'Ce que je redoute',
        preserve: 'Ce que je veux préserver'
    };
    return labels[category] || '';
}

// Select predefined word
function selectPredefinedWord(text) {
    if (!pendingPosition) {
        closeModal();
        return;
    }

    // Add word to state
    const word = {
        id: Date.now(),
        text: text,
        x: pendingPosition.x,
        y: pendingPosition.y
    };

    compassState.words.push(word);
    saveWords();
    renderWord(word);
    closeModal();
}

// Make global for onclick
window.selectPredefinedWord = selectPredefinedWord;

// Close modal
function closeModal() {
    inputModal.classList.add('hidden');
    pendingPosition = null;
}

// Save custom word
function saveWord() {
    const text = wordInput.value.trim();

    if (!text) {
        alert('Veuillez écrire quelque chose.');
        return;
    }

    if (!pendingPosition) {
        closeModal();
        return;
    }

    // Add word to state
    const word = {
        id: Date.now(),
        text: text,
        x: pendingPosition.x,
        y: pendingPosition.y
    };

    compassState.words.push(word);
    saveWords();
    renderWord(word);
    closeModal();
}

// Render a single word
function renderWord(word) {
    const wordElement = document.createElement('div');
    wordElement.className = 'word-item';
    wordElement.dataset.id = word.id;
    wordElement.style.left = `${word.x}%`;
    wordElement.style.top = `${word.y}%`;
    wordElement.innerHTML = `
        <span class="word-text">${escapeHtml(word.text)}</span>
        <button class="word-delete" onclick="deleteWord(${word.id})">×</button>
    `;

    // Make word draggable
    makeWordDraggable(wordElement, word);

    wordsContainer.appendChild(wordElement);
}

// Make word draggable
function makeWordDraggable(element, word) {
    let isDragging = false;

    element.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('word-delete')) return;

        isDragging = true;
        element.classList.add('dragging');

        e.preventDefault();
        e.stopPropagation();
    });

    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;

        const rect = compassCircle.getBoundingClientRect();

        // Calculate mouse position relative to compass circle
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        // Convert to percentage
        const newX = (mouseX / rect.width) * 100;
        const newY = (mouseY / rect.height) * 100;

        // Check if position is within circle bounds
        const centerX = 50;
        const centerY = 50;
        const dx = newX - centerX;
        const dy = newY - centerY;
        const distanceFromCenter = Math.sqrt(dx * dx + dy * dy);

        // Radius constraints
        const maxRadius = 45;
        const minRadius = 12;

        if (distanceFromCenter >= minRadius && distanceFromCenter <= maxRadius) {
            element.style.left = `${newX}%`;
            element.style.top = `${newY}%`;

            word.x = newX;
            word.y = newY;
        }
    });

    document.addEventListener('mouseup', () => {
        if (isDragging) {
            isDragging = false;
            element.classList.remove('dragging');
            saveWords();
        }
    });
}

// Render all words
function renderAllWords() {
    wordsContainer.innerHTML = '';
    compassState.words.forEach(word => renderWord(word));
}

// Delete a word
function deleteWord(id) {
    if (!confirm('Voulez-vous vraiment supprimer ce mot ?')) {
        return;
    }

    compassState.words = compassState.words.filter(w => w.id !== id);
    saveWords();
    renderAllWords();
}

// Make global for onclick
window.deleteWord = deleteWord;

// Clear all words
function clearAllWords() {
    if (!confirm('Voulez-vous vraiment effacer tous vos mots ? Cette action est irréversible.')) {
        return;
    }

    compassState.words = [];
    saveWords();
    renderAllWords();
}

// Save to localStorage
function saveWords() {
    localStorage.setItem('etpCompassWords', JSON.stringify(compassState.words));
}

// Load from localStorage
function loadWords() {
    const saved = localStorage.getItem('etpCompassWords');
    if (saved) {
        try {
            compassState.words = JSON.parse(saved);
        } catch (e) {
            console.error('Error loading words:', e);
        }
    }
}

// Print compass
function printCompass() {
    window.print();
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Escape for JS string
function escapeForJs(text) {
    return text.replace(/'/g, "\\'").replace(/"/g, '\\"');
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCompass);
} else {
    initCompass();
}
