// Patient Module Data
const patientModules = [
  {
    id: 0,
    number: "BILAN",
    title: "Bilan Éducatif",
    objective: "Évaluer vos besoins et réfléchir sur votre parcours",
    skills: [
      "Identifier les professionnels utiles pour votre prise en charge",
      "Réfléchir sur vos ressentis et besoins",
      "Faire le point sur votre parcours de soins"
    ],
    icon: "📋",
    color: "hsl(280, 60%, 55%)",
    content: {
      workshops: [
        {
          id: "w0-1",
          title: "Tinder métier",
          description: "Identifiez les professionnels qui vous semblent utiles pour la prise en charge de la SLA (système de swipe interactif)",
          icon: "👨‍⚕️",
          link: "assessment.html"
        },
        {
          id: "w0-2",
          title: "Ma Boussole ETP",
          description: "Placez librement vos réflexions sur la boussole : ce qui vous aide, ce qui est difficile, ce que vous redoutez, ce que vous voulez préserver",
          icon: "🧭",
          link: "compass.html"
        },
        {
          id: "w0-3",
          title: "Le jeu des cartes",
          description: "Sélectionnez 3 émotions + 3 difficultés parmi 22 cartes (6 cartes au total)",
          icon: "🃏",
          link: "emotions.html"
        },
        {
          id: "w0-4",
          title: "Votre journée type",
          description: "Planifiez et visualisez vos activités hebdomadaires sur un calendrier interactif",
          icon: "📅",
          link: "schedule.html"
        },
        {
          id: "w0-5",
          title: "Parcours de vie",
          description: "Tracez l'évolution de votre bien-être avant et après le diagnostic sur un graphique interactif",
          icon: "📈",
          link: "lifejourney.html"
        }
      ]
    }
  },
  {
    id: 1,
    number: "MODULE 1",
    title: "Présentation de la maladie",
    objective: "Comprendre la maladie et son évolution",
    skills: [
      "Expliquer les mécanismes de la maladie",
      "Identifier les symptômes moteurs et respiratoires",
      "Connaître les traitements non médicamenteux possibles"
    ],
    icon: "🏥",
    color: "hsl(210, 70%, 50%)",
    content: {
      videos: [
        {
          id: "v1-1",
          title: "Présentation globale de la maladie",
          duration: "12:30",
          thumbnail: "📹"
        },
        {
          id: "v1-2",
          title: "Présentation des troubles",
          duration: "15:45",
          thumbnail: "📹"
        },
        {
          id: "v1-3",
          title: "Les différents types de prise en charge",
          duration: "18:20",
          thumbnail: "📹"
        },
        {
          id: "v1-4",
          title: "Les traitements non-médicamenteux",
          duration: "14:10",
          thumbnail: "📹"
        }
      ]
    }
  },
  {
    id: 2,
    number: "MODULE 2",
    title: "Gestion des troubles / symptômes",
    objective: "Agir face aux différents troubles et symptômes",
    skills: [
      "Reproduire les exercices d'auto-soins pour les symptômes respiratoires et moteurs",
      "Mettre en place des recettes et habitudes alimentaires adaptées"
    ],
    icon: "💪",
    color: "hsl(180, 65%, 45%)",
    content: {
      videos: [
        {
          id: "v2-1",
          title: "Présentation des différentes méthodes d'auto-soins",
          duration: "20:15",
          thumbnail: "📹"
        },
        {
          id: "v2-2",
          title: "Diététique et recettes",
          duration: "16:30",
          thumbnail: "📹"
        }
      ],
      workshops: [
        {
          id: "w2-1",
          title: "Atelier moteur et soins",
          description: "Exercices pratiques pour maintenir la mobilité et apprendre les gestes d'auto-soins quotidiens",
          icon: "🏃"
        },
        {
          id: "w2-2",
          title: "Atelier planification de repas",
          description: "Apprendre à planifier des repas équilibrés et adaptés aux besoins nutritionnels spécifiques",
          icon: "🍽️"
        }
      ]
    }
  },
  {
    id: 3,
    number: "MODULE 3",
    title: "Gestion émotionnelle",
    objective: "Limiter la fatigue émotionnelle et maintenir sa santé mentale",
    skills: [
      "Exprimer ses émotions, se questionner",
      "Identifier les signes de détresse personnelle",
      "Demander de l'aide à des professionnels ou associations",
      "Mettre en place des stratégies de relaxation"
    ],
    icon: "🧘",
    color: "hsl(270, 60%, 60%)",
    content: {
      workshops: [
        {
          id: "w3-1",
          title: "Atelier relaxation et respiration",
          description: "Techniques de relaxation et exercices de respiration pour gérer le stress et l'anxiété",
          icon: "🌬️"
        },
        {
          id: "w3-2",
          title: "Groupe de parole « émotions »",
          description: "Espace d'échange pour partager ses émotions et expériences avec d'autres patients",
          icon: "💬"
        },
        {
          id: "w3-3",
          title: "Groupe de parole « libre »",
          description: "Session ouverte pour discuter de tous sujets dans un environnement bienveillant",
          icon: "🗣️"
        },
        {
          id: "w3-4",
          title: "Atelier « si nécessaire »",
          description: "Support complémentaire personnalisé selon les besoins identifiés",
          icon: "🆘"
        }
      ]
    }
  },
  {
    id: 4,
    number: "MODULE 4",
    title: "Communication",
    objective: "Préserver le lien social et le maintenir",
    skills: [
      "Utiliser des outils adéquats afin de maintenir la communication",
      "Exprimer ses besoins, ses envies et ses émotions"
    ],
    icon: "💬",
    color: "hsl(150, 60%, 50%)",
    content: {
      videos: [
        {
          id: "v4-1",
          title: "Introduction aux troubles du langage",
          duration: "13:40",
          thumbnail: "📹"
        },
        {
          id: "v4-2",
          title: "Présentation des différents moyens de communication non-verbale",
          duration: "17:25",
          thumbnail: "📹"
        }
      ],
      workshops: [
        {
          id: "w4-1",
          title: "Atelier individuel : les outils de communication",
          description: "Apprentissage personnalisé des outils et technologies de communication adaptative",
          icon: "📱"
        }
      ]
    }
  },
  {
    id: 5,
    number: "MODULE 5",
    title: "Fin de vie et deuil",
    objective: "Favoriser un accompagnement respectueux et digne",
    skills: [
      "Comprendre les enjeux de fin de vie",
      "Exprimer ses souhaits et continuer la prise de décision"
    ],
    icon: "🕊️",
    color: "hsl(200, 50%, 55%)",
    content: {
      workshops: [
        {
          id: "w5-1",
          title: "Groupe de parole",
          description: "Espace sécurisé pour échanger sur les préoccupations liées à la fin de vie",
          icon: "💭"
        },
        {
          id: "w5-2",
          title: "Ateliers écriture sur les souhaits et envies du patient",
          description: "Accompagnement pour mettre par écrit vos volontés et souhaits pour l'avenir",
          icon: "✍️"
        }
      ]
    }
  }
];
