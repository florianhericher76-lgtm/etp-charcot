// Difficulties Selection Application

// All available difficulties with colors
const difficulties = [
    { id: 1, name: "PERTE D'APPÉTIT", color: '#FFE5E5' },
    { id: 2, name: 'PERTE MÉMOIRE', color: '#FFE5B4' },
    { id: 3, name: 'PROBLÈME DE COMMUNICATION', color: '#FFE5B4' },
    { id: 4, name: 'HYPERACTIVITÉ', color: '#FFFACD' },
    { id: 5, name: 'INATTENTION', color: '#FFE5B4' },
    { id: 6, name: 'IMPULSIVITÉ', color: '#FFE5B4' },
    { id: 7, name: "PERTE D'INTÉRÊT", color: '#FFE4E1' },
    { id: 8, name: "BAISSE D'ÉNERGIE", color: '#E6E6FA' }
];

// State management
const difficultyState = {
    selected: [] // Array of difficulty IDs
};

// DOM Elements
const difficultiesGrid = document.getElementById('difficultiesGrid');
const selectedCount = document.getElementById('selectedCount');
const resetBtn = document.getElementById('reset-btn');
const validateBtn = document.getElementById('validate-btn');
const summaryModal = document.getElementById('summaryModal');
const selectedDifficultiesDiv = document.getElementById('selectedDifficulties');
const closeModalBtn = document.getElementById('closeModal');
const saveAndReturnBtn = document.getElementById('saveAndReturn');

// Initialize
function initDifficulties() {
    loadSelectedDifficulties();
    renderDifficultyCards();
    updateUI();

    // Event listeners
    resetBtn.addEventListener('click', resetSelection);
    validateBtn.addEventListener('click', showSummary);
    closeModalBtn.addEventListener('click', closeSummary);
    saveAndReturnBtn.addEventListener('click', saveAndReturn);
}

// Render difficulty cards
function renderDifficultyCards() {
    difficultiesGrid.innerHTML = '';

    difficulties.forEach(difficulty => {
        const card = document.createElement('div');
        card.className = 'difficulty-card';
        card.dataset.id = difficulty.id;

        const isSelected = difficultyState.selected.includes(difficulty.id);
        if (isSelected) {
            card.classList.add('selected');
        }

        card.style.backgroundColor = difficulty.color;

        card.innerHTML = `
            <div class="difficulty-name">${difficulty.name}</div>
            <div class="selection-indicator">✓</div>
        `;

        card.addEventListener('click', () => toggleDifficulty(difficulty.id));

        difficultiesGrid.appendChild(card);
    });
}

// Toggle difficulty selection
function toggleDifficulty(difficultyId) {
    const index = difficultyState.selected.indexOf(difficultyId);

    if (index > -1) {
        // Deselect
        difficultyState.selected.splice(index, 1);
    } else {
        // Select only if less than 3
        if (difficultyState.selected.length < 3) {
            difficultyState.selected.push(difficultyId);
        } else {
            alert('Vous ne pouvez sélectionner que 3 difficultés maximum.');
            return;
        }
    }

    saveSelectedDifficulties();
    renderDifficultyCards();
    updateUI();
}

// Update UI (counter and validate button)
function updateUI() {
    const count = difficultyState.selected.length;
    selectedCount.textContent = count;

    // Enable validate button only if exactly 3 difficulties are selected
    validateBtn.disabled = count !== 3;
}

// Reset selection
function resetSelection() {
    if (!confirm('Voulez-vous vraiment recommencer votre sélection ?')) {
        return;
    }

    difficultyState.selected = [];
    saveSelectedDifficulties();
    renderDifficultyCards();
    updateUI();
}

// Show summary modal
function showSummary() {
    if (difficultyState.selected.length !== 3) {
        alert('Veuillez sélectionner exactement 3 difficultés.');
        return;
    }

    // Render selected difficulties
    selectedDifficultiesDiv.innerHTML = '';

    difficultyState.selected.forEach(difficultyId => {
        const difficulty = difficulties.find(d => d.id === difficultyId);
        if (difficulty) {
            const difficultyCard = document.createElement('div');
            difficultyCard.className = 'summary-difficulty-card';
            difficultyCard.style.backgroundColor = difficulty.color;
            difficultyCard.innerHTML = `
                <div class="difficulty-name-large">${difficulty.name}</div>
            `;
            selectedDifficultiesDiv.appendChild(difficultyCard);
        }
    });

    summaryModal.classList.remove('hidden');
}

// Close summary
function closeSummary() {
    summaryModal.classList.add('hidden');
}

// Save and return to modules
function saveAndReturn() {
    saveSelectedDifficulties();
    alert('Vos difficultés ont été enregistrées !');
    window.location.href = 'index.html';
}

// Save to localStorage
function saveSelectedDifficulties() {
    localStorage.setItem('etpSelectedDifficulties', JSON.stringify(difficultyState.selected));
}

// Load from localStorage
function loadSelectedDifficulties() {
    const saved = localStorage.getItem('etpSelectedDifficulties');
    if (saved) {
        try {
            difficultyState.selected = JSON.parse(saved);
        } catch (e) {
            console.error('Error loading difficulties:', e);
        }
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initDifficulties);
} else {
    initDifficulties();
}
