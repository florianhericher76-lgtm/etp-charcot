// Life Journey - Interactive Life Path Graph
// Allows users to trace their wellbeing before and after diagnosis

// App State
let points = [];
let selectedPoint = null;
let isDragging = false;
let mouseDownPos = null;
let hasMoved = false;

// Canvas and context
const canvas = document.getElementById('lifejourney-canvas');
const ctx = canvas.getContext('2d');

// Buttons
const saveBtn = document.getElementById('save-btn');
const clearBtn = document.getElementById('clear-btn');

// Modal elements
const pointModal = document.getElementById('point-modal');
const modalOverlay = document.getElementById('modal-overlay');
const modalClose = document.getElementById('modal-close');
const pointForm = document.getElementById('point-form');
const pointNoteInput = document.getElementById('point-note');
const cancelNoteBtn = document.getElementById('cancel-note-btn');
const removeNoteBtn = document.getElementById('remove-note-btn');

// Constants
const DIAGNOSIS_POSITION = 0.5; // Middle of canvas (50%)
const POINT_RADIUS = 8;
const POINT_HOVER_RADIUS = 12;

// Colors  
const BEFORE_COLOR = '#4A90E2'; // Bleu pour "Avant"
const AFTER_COLOR = '#FF6B45'; // Orange pour "Après"
const LINE_COLOR = '#8B7FCD'; // Violet pour la courbe
const GRID_COLOR = 'rgba(255, 255, 255, 0.1)';
const AXIS_COLOR = 'rgba(255, 255, 255, 0.3)';

// Setup canvas
function setupCanvas() {
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * window.devicePixelRatio;
    canvas.height = rect.height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
}

// Get mouse position relative to canvas
function getMousePos(e) {
    const rect = canvas.getBoundingClientRect();
    return {
        x: (e.clientX - rect.left) / rect.width,
        y: (e.clientY - rect.top) / rect.height
    };
}

// Get touch position relative to canvas
function getTouchPos(e) {
    if (e.touches.length > 0) {
        const rect = canvas.getBoundingClientRect();
        return {
            x: (e.touches[0].clientX - rect.left) / rect.width,
            y: (e.touches[0].clientY - rect.top) / rect.height
        };
    }
    return null;
}

// Draw grid
function drawGrid() {
    const rect = canvas.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    ctx.strokeStyle = GRID_COLOR;
    ctx.lineWidth = 1;

    // Horizontal lines
    for (let i = 0; i <= 4; i++) {
        const y = (height / 4) * i;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
    }

    // Vertical lines (diagnostic line in the middle)
    ctx.strokeStyle = AXIS_COLOR;
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    const diagnosisX = width * DIAGNOSIS_POSITION;
    ctx.beginPath();
    ctx.moveTo(diagnosisX, 0);
    ctx.lineTo(diagnosisX, height);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw "Avant" and "Après" labels
    ctx.font = 'bold 16px Inter';
    ctx.textAlign = 'center';

    ctx.fillStyle = BEFORE_COLOR;
    ctx.fillText('Avant', width * 0.25, 30);

    ctx.fillStyle = AFTER_COLOR;
    ctx.fillText('Après', width * 0.75, 30);
}

// Draw the curve connecting points
function drawCurve() {
    if (points.length < 2) return;

    const rect = canvas.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    // Sort points by x position
    const sortedPoints = [...points].sort((a, b) => a.x - b.x);

    ctx.strokeStyle = LINE_COLOR;
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Draw smooth curve through points
    ctx.beginPath();
    ctx.moveTo(sortedPoints[0].x * width, sortedPoints[0].y * height);

    for (let i = 0; i < sortedPoints.length - 1; i++) {
        const current = sortedPoints[i];
        const next = sortedPoints[i + 1];

        const currentX = current.x * width;
        const currentY = current.y * height;
        const nextX = next.x * width;
        const nextY = next.y * height;

        // Calculate control points for smooth curve
        const controlX = (currentX + nextX) / 2;
        const controlY = (currentY + nextY) / 2;

        ctx.quadraticCurveTo(currentX, currentY, controlX, controlY);
    }

    // Final point
    const last = sortedPoints[sortedPoints.length - 1];
    ctx.lineTo(last.x * width, last.y * height);
    ctx.stroke();
}

// Draw points
function drawPoints() {
    const rect = canvas.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    points.forEach((point, index) => {
        const x = point.x * width;
        const y = point.y * height;

        // Determine color based on position
        const color = point.x < DIAGNOSIS_POSITION ? BEFORE_COLOR : AFTER_COLOR;

        // Draw point
        ctx.beginPath();
        ctx.arc(x, y, POINT_RADIUS, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();

        // Draw outline
        ctx.strokeStyle = 'white';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Draw note indicator if point has a note
        if (point.note) {
            ctx.fillStyle = 'white';
            ctx.font = 'bold 10px Inter';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('i', x, y);
        }

        // Highlight selected point
        if (selectedPoint === index) {
            ctx.beginPath();
            ctx.arc(x, y, POINT_HOVER_RADIUS, 0, Math.PI * 2);
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
            ctx.lineWidth = 3;
            ctx.stroke();
        }

        // Draw note label if exists
        if (point.note) {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
            ctx.font = '11px Inter';
            ctx.textAlign = 'center';
            const noteY = y - POINT_RADIUS - 8;

            // Background for note
            const textWidth = ctx.measureText(point.note).width;
            ctx.fillRect(x - textWidth / 2 - 4, noteY - 10, textWidth + 8, 16);

            // Note text
            ctx.fillStyle = 'white';
            ctx.fillText(point.note, x, noteY);
        }
    });
}

// Render canvas
function render() {
    const rect = canvas.getBoundingClientRect();
    ctx.clearRect(0, 0, rect.width, rect.height);

    drawGrid();
    drawCurve();
    drawPoints();
}

// Find point near position
function findPointNear(pos) {
    const rect = canvas.getBoundingClientRect();
    const threshold = 15 / rect.width; // 15px in normalized coords

    return points.findIndex(point => {
        const dx = point.x - pos.x;
        const dy = point.y - pos.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        return distance < threshold;
    });
}

// Mouse down handler
function handleMouseDown(e) {
    const pos = getMousePos(e);
    const nearPoint = findPointNear(pos);

    mouseDownPos = pos;
    hasMoved = false;

    if (nearPoint !== -1) {
        selectedPoint = nearPoint;
        isDragging = true; // Ready to drag if user moves
    } else {
        // Add new point
        points.push({ x: pos.x, y: pos.y, note: '' });
        selectedPoint = points.length - 1;
        openNoteModal();
    }
    render();
}

// Mouse move handler
function handleMouseMove(e) {
    const pos = getMousePos(e);

    // Detect if mouse has moved significantly
    if (mouseDownPos && isDragging) {
        const dx = Math.abs(pos.x - mouseDownPos.x);
        const dy = Math.abs(pos.y - mouseDownPos.y);
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance > 0.01) { // Threshold for movement detection
            hasMoved = true;
        }
    }

    if (isDragging && selectedPoint !== null && hasMoved) {
        const oldNote = points[selectedPoint].note; // Preserve note
        points[selectedPoint] = {
            x: Math.max(0, Math.min(1, pos.x)),
            y: Math.max(0, Math.min(1, pos.y)),
            note: oldNote // Restore note
        };
        render();
    } else {
        // Change cursor if hovering over point
        const nearPoint = findPointNear(pos);
        canvas.style.cursor = nearPoint !== -1 ? 'pointer' : 'crosshair';
    }
}

// Mouse up handler
function handleMouseUp() {
    // If user clicked without moving, open modal to edit
    if (isDragging && selectedPoint !== null && !hasMoved) {
        openNoteModal();
    }

    if (isDragging && hasMoved) {
        saveData();
    }

    isDragging = false;
    mouseDownPos = null;
    hasMoved = false;
}

// Touch handlers
function handleTouchStart(e) {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    if (e.touches.length > 0) {
        handleMouseDown({
            clientX: e.touches[0].clientX,
            clientY: e.touches[0].clientY
        });
    }
}

function handleTouchMove(e) {
    e.preventDefault();
    if (e.touches.length > 0) {
        handleMouseMove({
            clientX: e.touches[0].clientX,
            clientY: e.touches[0].clientY
        });
    }
}

function handleTouchEnd(e) {
    e.preventDefault();
    handleMouseUp();
}

// Save data to localStorage
function saveData() {
    localStorage.setItem('lifeJourneyData', JSON.stringify(points));
}

// Load data from localStorage
function loadData() {
    const saved = localStorage.getItem('lifeJourneyData');
    if (saved) {
        points = JSON.parse(saved);
        render();
    }
}

// Open note modal
function openNoteModal() {
    if (selectedPoint === null) return;

    const point = points[selectedPoint];
    pointNoteInput.value = point.note || '';
    pointModal.classList.remove('hidden');

    setTimeout(() => pointNoteInput.focus(), 100);
}

// Close note modal
function closeNoteModal() {
    pointModal.classList.add('hidden');
}

// Handle note form submission
pointForm.addEventListener('submit', (e) => {
    e.preventDefault();

    if (selectedPoint !== null) {
        points[selectedPoint].note = pointNoteInput.value.trim();
        saveData();
        render();
        closeNoteModal();
        showFeedback('Note ajoutée ✓');
    }
});

// Remove note
removeNoteBtn.addEventListener('click', () => {
    if (selectedPoint !== null) {
        points[selectedPoint].note = '';
        saveData();
        render();
        closeNoteModal();
        showFeedback('Note retirée ✓');
    }
});

// Modal close handlers
modalClose.addEventListener('click', closeNoteModal);
cancelNoteBtn.addEventListener('click', closeNoteModal);
modalOverlay.addEventListener('click', closeNoteModal);

// Escape key to close modal
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !pointModal.classList.contains('hidden')) {
        closeNoteModal();
    }
});

// Clear all points
clearBtn.addEventListener('click', () => {
    if (confirm('Êtes-vous sûr de vouloir effacer tout le graphique ?')) {
        points = [];
        selectedPoint = null;
        saveData();
        render();
        showFeedback('Graphique effacé ✓');
    }
});

// Save button
saveBtn.addEventListener('click', () => {
    saveData();
    showFeedback('Parcours sauvegardé ✓');
});

// Show feedback message
function showFeedback(message) {
    const feedback = document.createElement('div');
    feedback.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: linear-gradient(135deg, #4ECDC4, #44A08D);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 12px;
        font-weight: 600;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        z-index: 2000;
        animation: slideIn 0.3s ease;
    `;
    feedback.textContent = message;
    document.body.appendChild(feedback);

    setTimeout(() => {
        feedback.remove();
    }, 3000);
}

// Event listeners
canvas.addEventListener('mousedown', handleMouseDown);
canvas.addEventListener('mousemove', handleMouseMove);
canvas.addEventListener('mouseup', handleMouseUp);
canvas.addEventListener('mouseleave', handleMouseUp);

// Touch events
canvas.addEventListener('touchstart', handleTouchStart, { passive: false });
canvas.addEventListener('touchmove', handleTouchMove, { passive: false });
canvas.addEventListener('touchend', handleTouchEnd, { passive: false });

// Window resize
window.addEventListener('resize', () => {
    setupCanvas();
    render();
});

// Initialize
setupCanvas();
loadData();
render();
